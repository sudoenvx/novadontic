import type { Server as HttpServer } from 'node:http';
import { Server as SocketServer } from 'socket.io';

export function attachSocketServer(
  httpServer: HttpServer,
): SocketServer {
  return new SocketServer(httpServer);
}
