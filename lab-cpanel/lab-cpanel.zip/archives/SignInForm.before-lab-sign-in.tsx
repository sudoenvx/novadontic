import { Eye, EyeOff } from 'lucide-react'
import { useId, useState, type FormEvent } from 'react'
import { Link } from 'react-router-dom'

import { Button } from '../src/shared/ui/Button'
import { Checkbox } from '../src/shared/ui/Checkbox'
import { Input } from '../src/shared/ui/Input'
import { Label } from '../src/shared/ui/Label'
import type { LabSignInValues } from '../src/features/auth/domain/auth'
import { validateLabSignIn } from '../src/features/auth/domain/auth'

type SignInFormProps = {
  onSubmit: (values: LabSignInValues) => void;
}

const initialValues: LabSignInValues = {
  email: "",
  password: "",
  rememberDevice: true,
}

export function SignInForm({ onSubmit }: SignInFormProps) {
  const [values, setValues] = useState(initialValues)
  const [error, setError] = useState<string>()
  const [isPasswordVisible, setIsPasswordVisible] = useState(false)
  const emailId = useId()
  const passwordId = useId()
  const rememberDeviceId = useId()

  function updateValue<Key extends keyof LabSignInValues>(
    key: Key,
    value: LabSignInValues[Key],
  ) {
    setValues((current) => ({ ...current, [key]: value }))
    setError(undefined)
  }

  function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    const validationError = validateLabSignIn(values)

    if (validationError) {
      setError(validationError)
      return
    }

    onSubmit({
      ...values,
      email: values.email.trim().toLowerCase(),
    })
  }

  return (
    <form className="grid gap-4" onSubmit={handleSubmit} noValidate>
      <div className="grid gap-1.5">
        <Label htmlFor={emailId}>Email</Label>
        <Input
          id={emailId}
          type="email"
          value={values.email}
          onChange={(event) => updateValue('email', event.currentTarget.value)}
          placeholder="name@yourlab.com"
          autoComplete="email"
          autoFocus
          aria-invalid={Boolean(error)}
        />
      </div>

      <div className="grid gap-1.5">
        <Label htmlFor={passwordId}>Password</Label>
        <div className="relative">
          <Input
            id={passwordId}
            type={isPasswordVisible ? "text" : "password"}
            value={values.password}
            onChange={(event) =>
              updateValue('password', event.currentTarget.value)
            }
            placeholder="Enter your password"
            autoComplete="current-password"
            className="pe-10"
            aria-invalid={Boolean(error)}
          />
          <Button
            type="button"
            variant="ghost"
            size="icon-sm"
            className="absolute end-1 top-1/2 -translate-y-1/2"
            onClick={() => setIsPasswordVisible((visible) => !visible)}
            aria-label={isPasswordVisible ? "Hide password" : "Show password"}
            aria-pressed={isPasswordVisible}
          >
            {isPasswordVisible ? <EyeOff /> : <Eye />}
          </Button>
        </div>
      </div>

      <div className="flex items-center justify-between gap-3">
        <Label htmlFor={rememberDeviceId} className="cursor-pointer gap-2 text-xs font-medium text-text-secondary">
          <Checkbox
            id={rememberDeviceId}
            checked={values.rememberDevice}
            onCheckedChange={(checked) =>
              updateValue('rememberDevice', checked === true)
            }
          />
          Remember this device
        </Label>
        <Link to="/forgot-password" className="text-xs font-semibold text-primary underline-offset-4 hover:underline">
          Forgot password?
        </Link>
      </div>

      {error && (
        <p className="text-xs text-destructive" role="alert" aria-live="assertive">
          {error}
        </p>
      )}
      <Button type="submit" size="lg" className="mt-1 w-full">
        Sign in
      </Button>
    </form>
  )
}
